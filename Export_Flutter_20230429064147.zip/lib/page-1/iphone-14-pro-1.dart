import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14pro1meE (1:2)
        padding: EdgeInsets.fromLTRB(0*fem, 6*fem, 0*fem, 56*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // nativestatusbarkuU (1:971)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 55*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 5*fem, 16.02*fem, 0*fem),
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // puL (I1:971;21:140)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 236*fem, 0*fem),
                    child: Text(
                      '9:41',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w500,
                        height: 0.8888888889*ffem/fem,
                        color: Color(0xff090a0a),
                      ),
                    ),
                  ),
                  Container(
                    // mobilesignal5aN (I1:971;21:141)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 1.5*fem),
                    width: 18*fem,
                    height: 10*fem,
                    child: Image.asset(
                      'assets/page-1/images/mobile-signal.png',
                      width: 18*fem,
                      height: 10*fem,
                    ),
                  ),
                  Container(
                    // wifiyve (I1:971;21:147)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.73*fem, 2.03*fem),
                    width: 15.27*fem,
                    height: 10.97*fem,
                    child: Image.asset(
                      'assets/page-1/images/wifi.png',
                      width: 15.27*fem,
                      height: 10.97*fem,
                    ),
                  ),
                  Container(
                    // batteryUcW (I1:971;21:152)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                    width: 26.98*fem,
                    height: 13*fem,
                    child: Image.asset(
                      'assets/page-1/images/battery.png',
                      width: 26.98*fem,
                      height: 13*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // searchzKx (1:990)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 44*fem, 34*fem),
              padding: EdgeInsets.fromLTRB(73*fem, 16*fem, 33*fem, 0*fem),
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(6*fem),
              ),
              child: Text(
                'TEMPERATURE IN CELSIUS ',
                textAlign: TextAlign.right,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 16*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.5*ffem/fem,
                  color: Color(0xff404446),
                ),
              ),
            ),
            Container(
              // frame320RgA (1:737)
              margin: EdgeInsets.fromLTRB(29*fem, 0*fem, 30*fem, 34*fem),
              padding: EdgeInsets.fromLTRB(36*fem, 5*fem, 11*fem, 31*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // cardbody7ot (1:738)
                    margin: EdgeInsets.fromLTRB(29*fem, 0*fem, 54*fem, 17*fem),
                    padding: EdgeInsets.fromLTRB(21*fem, 12.5*fem, 21*fem, 13.5*fem),
                    width: double.infinity,
                    height: 189*fem,
                    child: Container(
                      // chartgraphicdnE (1:739)
                      width: double.infinity,
                      height: double.infinity,
                      child: Container(
                        // group7d9x (I1:739;18:1152)
                        width: double.infinity,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse19NNS (I1:739;18:1153)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 162*fem,
                                  height: 162*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-19.png',
                                    width: 162*fem,
                                    height: 162*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // ellipse18ear (I1:739;18:1154)
                              left: 0*fem,
                              top: 1*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 162*fem,
                                  height: 162*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-18.png',
                                    width: 162*fem,
                                    height: 162*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // jsC (I1:739;18:1155)
                              left: 59*fem,
                              top: 67*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 30*fem,
                                  child: Text(
                                    '35°C',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 25*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xff979c9e),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // cardfooterpNr (1:740)
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    height: 22*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame77Tgi (1:741)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 2*fem),
                          width: 124*fem,
                          height: 20*fem,
                          child: Container(
                            // frame79yux (1:742)
                            width: double.infinity,
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // frame61vqC (1:743)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                  width: 20*fem,
                                  height: double.infinity,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffb323),
                                    borderRadius: BorderRadius.circular(4*fem),
                                  ),
                                ),
                                Text(
                                  // currenttempRmx (1:744)
                                  'CURRENT TEMP',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1666666667*ffem/fem,
                                    color: Color(0xff979c9e),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // frame78m58 (1:745)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 1*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame62tfY (1:746)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                width: 20*fem,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  color: Color(0xffeeeeee),
                                  borderRadius: BorderRadius.circular(4*fem),
                                ),
                              ),
                              Text(
                                // maximumtempcrS (1:747)
                                'MAXIMUM TEMP',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.1666666667*ffem/fem,
                                  color: Color(0xff979c9e),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // searchMp2 (1:993)
              margin: EdgeInsets.fromLTRB(41*fem, 0*fem, 34*fem, 1*fem),
              width: double.infinity,
              height: 65*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(6*fem),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // rectangle249g5c (1:994)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 309*fem,
                        height: 65*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(6*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group468xYv (1:995)
                    left: 120*fem,
                    top: 25*fem,
                    child: Container(
                      width: 198*fem,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // GpW (1:996)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41*fem, 0*fem),
                            child: Text(
                              '06.04.2023',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff979c9e),
                              ),
                            ),
                          ),
                          RichText(
                            // c29cN6r (1:1005)
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff979c9e),
                              ),
                              children: [
                                TextSpan(
                                  text: '40',
                                ),
                                TextSpan(
                                  text: '°C /29°C ',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xff979c9e),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // thursdayMcz (1:1004)
                    left: 8*fem,
                    top: 25*fem,
                    child: Align(
                      child: SizedBox(
                        width: 71*fem,
                        height: 16*fem,
                        child: Text(
                          'THURSDAY',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1428571429*ffem/fem,
                            color: Color(0xff979c9e),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // searchB6E (1:1006)
              margin: EdgeInsets.fromLTRB(42*fem, 0*fem, 35*fem, 25*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(6*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // autogroupuwy9gYn (HXAJnFHxWYF6FsNhX1Uwy9)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 40*fem),
                    width: 313*fem,
                    height: 65*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // rectangle249a8N (1:1007)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 309*fem,
                              height: 65*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(6*fem),
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // group468FEW (1:1008)
                          left: 119*fem,
                          top: 33*fem,
                          child: Container(
                            width: 194*fem,
                            height: 16*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // 8JJ (1:1009)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                  child: Text(
                                    '07.04.2023',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1428571429*ffem/fem,
                                      color: Color(0xff979c9e),
                                    ),
                                  ),
                                ),
                                RichText(
                                  // c28cDKk (1:1010)
                                  text: TextSpan(
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1428571429*ffem/fem,
                                      color: Color(0xff979c9e),
                                    ),
                                    children: [
                                      TextSpan(
                                        text: '41',
                                      ),
                                      TextSpan(
                                        text: '°C /28°C ',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.1428571429*ffem/fem,
                                          color: Color(0xff979c9e),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // fridaynnA (1:1012)
                          left: 7*fem,
                          top: 33*fem,
                          child: Align(
                            child: SizedBox(
                              width: 47*fem,
                              height: 16*fem,
                              child: Text(
                                'FRIDAY',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1428571429*ffem/fem,
                                  color: Color(0xff979c9e),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // search62A (1:1013)
                    margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: 16*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // saturdayE8N (1:1019)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41*fem, 0*fem),
                          child: Text(
                            'SATURDAY',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1428571429*ffem/fem,
                              color: Color(0xff979c9e),
                            ),
                          ),
                        ),
                        Container(
                          // group468woU (1:1015)
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // 6RU (1:1016)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41*fem, 0*fem),
                                child: Text(
                                  '08.04.2023',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xff979c9e),
                                  ),
                                ),
                              ),
                              Text(
                                // c26c2K8 (1:1017)
                                '38°C /26°C ',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1428571429*ffem/fem,
                                  color: Color(0xff979c9e),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // searchMcJ (1:1020)
              margin: EdgeInsets.fromLTRB(40*fem, 0*fem, 35*fem, 0*fem),
              width: double.infinity,
              height: 65*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(6*fem),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // rectangle2495oC (1:1021)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 309*fem,
                        height: 65*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(6*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group468Ccv (1:1022)
                    left: 120*fem,
                    top: 25*fem,
                    child: Container(
                      width: 198*fem,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // wKc (1:1023)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41*fem, 0*fem),
                            child: Text(
                              '09.04.2023',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff979c9e),
                              ),
                            ),
                          ),
                          RichText(
                            // c29cGMt (1:1024)
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff979c9e),
                              ),
                              children: [
                                TextSpan(
                                  text: '40',
                                ),
                                TextSpan(
                                  text: '°C /29°C ',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xff979c9e),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // sundayW1L (1:1026)
                    left: 8*fem,
                    top: 25*fem,
                    child: Align(
                      child: SizedBox(
                        width: 56*fem,
                        height: 16*fem,
                        child: Text(
                          'SUNDAY',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1428571429*ffem/fem,
                            color: Color(0xff979c9e),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // searchQMc (1:1027)
              margin: EdgeInsets.fromLTRB(39*fem, 0*fem, 37*fem, 0*fem),
              width: double.infinity,
              height: 65*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(6*fem),
              ),
              child: Stack(
                children: [
                  Positioned(
                    // rectangle249vqk (1:1028)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 309*fem,
                        height: 65*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(6*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group468eFx (1:1029)
                    left: 120*fem,
                    top: 25*fem,
                    child: Container(
                      width: 197*fem,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // NSr (1:1030)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 46*fem, 0*fem),
                            child: Text(
                              '10.04.2023',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff979c9e),
                              ),
                            ),
                          ),
                          RichText(
                            // c27cJLW (1:1031)
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff979c9e),
                              ),
                              children: [
                                TextSpan(
                                  text: '38',
                                ),
                                TextSpan(
                                  text: '°C /27°C ',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    color: Color(0xff979c9e),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // mondayLY6 (1:1033)
                    left: 8*fem,
                    top: 25*fem,
                    child: Align(
                      child: SizedBox(
                        width: 61*fem,
                        height: 16*fem,
                        child: Text(
                          'MONDAY',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1428571429*ffem/fem,
                            color: Color(0xff979c9e),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}